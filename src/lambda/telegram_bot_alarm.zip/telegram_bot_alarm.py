import os
from urllib import request, parse
from textwrap import wrap

MAX_CHUNK_SIZE = 4096  # Maximum Telegram message length

def lambda_handler(event, context):
    url = 'https://api.telegram.org/bot{}/sendMessage'.format(os.environ['TOKEN'])
    message = event['Records'][0]['Sns']['Message']

    for chunk in wrap(message, MAX_CHUNK_SIZE):
        data = parse.urlencode({'chat_id': os.environ['CHAT_ID'], 'text': chunk})
        try:
            request.urlopen(url, data.encode('utf-8'))
        except Exception as e:
            print('Failed to send the SNS message below:\n{}'.format(chunk))
            raise e